const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: 'raghbir_store_secret_key_2026',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 3600000 } // 1 hour session
}));

const PRODUCTS_FILE = path.join(__dirname, 'products.json');

// Helper functions for database read/write
function getProducts() {
    if (!fs.existsSync(PRODUCTS_FILE)) {
        return [];
    }
    const data = fs.readFileSync(PRODUCTS_FILE, 'utf8');
    return JSON.parse(data || '[]');
}

function saveProducts(products) {
    fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2), 'utf8');
}

// Credentials
const ADMIN_USER = "jiwan";
const ADMIN_PASS = "raisar123*";

// Middleware to check authentication
function checkAuth(req, res, next) {
    if (req.session && req.session.isLoggedIn) {
        return next();
    }
    return res.status(401).json({ success: false, message: "Unauthorized. Please log in first." });
}

// API Routes
app.get('/api/products', (req, res) => {
    const products = getProducts();
    res.json({ products, isLoggedIn: !!(req.session && req.session.isLoggedIn) });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USER && password === ADMIN_PASS) {
        req.session.isLoggedIn = true;
        req.session.username = username;
        return res.json({ success: true, message: "Logged in successfully" });
    }
    return res.status(400).json({ success: false, message: "Invalid username or password" });
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: "Logged out successfully" });
});

app.post('/api/products', checkAuth, (req, res) => {
    const { name, category, price, unit, stock } = req.body;
    if (!name || !price) {
        return res.status(400).json({ success: false, message: "Name and Price are required" });
    }
    const products = getProducts();
    const newProduct = {
        id: Date.now(),
        name,
        category: category || "General Hardware",
        price: parseFloat(price),
        unit: unit || "piece",
        stock: parseInt(stock) || 0
    };
    products.push(newProduct);
    saveProducts(products);
    res.json({ success: true, product: newProduct });
});

app.put('/api/products/:id', checkAuth, (req, res) => {
    const productId = parseInt(req.params.id);
    const { name, category, price, unit, stock } = req.body;
    let products = getProducts();
    
    const index = products.findIndex(p => p.id === productId);
    if (index === -1) {
        return res.status(404).json({ success: false, message: "Product not found" });
    }

    products[index] = {
        ...products[index],
        name: name !== undefined ? name : products[index].name,
        category: category !== undefined ? category : products[index].category,
        price: price !== undefined ? parseFloat(price) : products[index].price,
        unit: unit !== undefined ? unit : products[index].unit,
        stock: stock !== undefined ? parseInt(stock) : products[index].stock
    };

    saveProducts(products);
    res.json({ success: true, product: products[index] });
});

app.delete('/api/products/:id', checkAuth, (req, res) => {
    const productId = parseInt(req.params.id);
    let products = getProducts();
    products = products.filter(p => p.id !== productId);
    saveProducts(products);
    res.json({ success: true, message: "Product deleted" });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

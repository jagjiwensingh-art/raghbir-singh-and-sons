==================================================
RAGHBIR SINGH & SONS - STORE & PRODUCT MANAGEMENT
==================================================

How to run the store application:

1. Install Node.js on your computer (if not already installed).
2. Open terminal/command prompt in this folder.
3. Run: npm install
4. Run: npm start
5. Open your browser and go to: http://localhost:3000

Login Details for Admin Panel:
- Username: jiwan
- Password: raisar123*

Features:
- View all building materials, steel, paint, and hardware products with real-time stock/price updates.
- Secure Admin Authentication (Password protected).
- Admin Dashboard to Add, Edit Price/Stock, and Delete products dynamically.
- Data automatically saved to local JSON database (`products.json`).
